#cleanup via find
# find . -name .svn -exec rm -r {} \;