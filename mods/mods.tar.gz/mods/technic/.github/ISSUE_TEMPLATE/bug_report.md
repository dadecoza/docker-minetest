---
name: Bug report
about: Report a problem within technic
title: ''
labels: Bug
assignees: ''

---

Technic has no main developer and largely depends on
user-provided Pull Requests. It will take a while until
even important issues are noticed.
Please consider proposing a PR directly.
_______________________________________________


**Bug description**


**Steps to reproduce this issue**
