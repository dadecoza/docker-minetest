-- Support for the old multi-load method
dofile(minetest.get_modpath("intllib").."/init.lua")

