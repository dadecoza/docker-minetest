
-- This file should be replaced by `intllib/lib/intllib.lua`.
return dofile(minetest.get_modpath("intllib").."/lib/intllib.lua")
