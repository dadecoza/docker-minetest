In this folder the skin files could be placed according the following file naming convention.

Public skin available for all users:
	character_[number-or-name].png

One or multiple private skins for player "nick":
	player_[nick].png or
	player_[nick]_[number-or-name].png

Preview files for public and private skins.
Optional, overrides the generated preview
	character_*_preview.png or
	player_*_*_preview.png
