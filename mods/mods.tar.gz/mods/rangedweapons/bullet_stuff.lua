

minetest.register_craftitem("rangedweapons:308shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "rangedweapons_308_shot.png",
})

minetest.register_craftitem("rangedweapons:handgunshot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "rangedweapons_9mm_shot.png",
})

minetest.register_craftitem("rangedweapons:smgshot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "rangedweapons_10mm_shot.png",
})

minetest.register_craftitem("rangedweapons:heavy_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "rangedweapons_726mm_shot.png",
})

minetest.register_craftitem("rangedweapons:assault_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "rangedweapons_556mm_shot.png",
})

minetest.register_craftitem("rangedweapons:magnum_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "rangedweapons_44_shot.png",
})







