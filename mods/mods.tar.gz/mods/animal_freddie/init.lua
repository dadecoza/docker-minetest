local version = "0.1.2"

minetest.log("action","MOD: loading animal_freddie ... ")

local freddie_groups = {
						not_in_creative_inventory=1
					}

local selectionbox_freddie = {-0.3, -1.0, -0.3, 0.3, 0.7, 0.3}

local modpath = minetest.get_modpath("animal_freddie")

dofile (modpath .. "/flame.lua")

function freddie_drop()
	local result = {}
	if math.random() < 0.05 then
		table.insert(result,"animalmaterials:bone 2")
	else
		table.insert(result,"animalmaterials:bone 1")
	end

	table.insert(result,"animalmaterials:meat_undead 1")

	return result
end

function freddie_on_step_handler(entity,now,dtime)
	local pos = entity.getbasepos(entity)
	local current_light = minetest.get_node_light(pos)
	if entity.dynamic_data.spawning.spawner == "at_night" or
		entity.dynamic_data.spawning.spawner == "at_night_mapgen" then
		local current_time = minetest.get_timeofday()
		if (current_time > 0.15) and
			(current_time < 0.30) then
			if entity.last_time ~= nil then
				local last_step_size = dtime /  86400 -- (24*3600)
				local time_step = current_time - entity.last_time
				if time_step > last_step_size * 1000 then
					print("freddie: time jump detected removing mob: " .. time_step .. " last_step_size: " .. (last_step_size * 1000))
					spawning.remove(entity)
					--return false to abort procession of other hooks
					return false
				end
			end
		end

		entity.last_time = current_time
	end
end

function freddie_on_activate_handler(entity)

	local pos = entity.object:getpos()

	local current_light = minetest.get_node_light(pos)

	if current_light == nil then
		minetest.log(LOGLEVEL_ERROR,
			"ANIMALS:freddie Bug!!! didn't get a light value for ".. printpos(pos))
		return
	end
end

local freddie_prototype = {
		name="freddie",
		modname="animal_freddie",

		factions = {
			member = {
				"monsters",
				"undead"
				}
			},

		generic = {
					description="freddie",
					base_health=8,
					kill_result=freddie_drop,
					armor_groups= {
						fleshy=95,
						daemon=30,
					},
					groups = freddie_groups,
					envid="on_ground_1",
					custom_on_step_handler = freddie_on_step_handler,
					custom_on_activate_handler = freddie_on_activate_handler,
					population_density=20,
					stepheight = 0.51,
				},
		movement =  {
					min_accel=0.3,
					max_accel=0.75,
					max_speed=1,
					pattern="stop_and_go",
					canfly=false,
					follow_speedup=20,
					},
		combat = {
					angryness=1,
					starts_attack=true,
					sun_sensitive=false,
					melee = {
						maxdamage=2,
						range=2,
						speed=1,
						},
					distance 		= nil,
					self_destruct 	= nil,
					},
		sound = {
					random = {
								name="animal_freddie_random_1",
								min_delta = 10,
								chance = 0.5,
								gain = 0.05,
								max_hear_distance = 5,
								},
					sun_damage = {
								name="animal_freddie_sun_damage",
								gain = 0.25,
								max_hear_distance = 7,
								},
					},
		animation = {
				stand = {
					start_frame = 0,
					end_frame   = 80,
					},
				walk = {
					start_frame = 168,
					end_frame   = 188,
					},
				attack = {
					start_frame = 168,
					end_frame   = 188,
					},
			},
		states = {
				{
					name = "default",
					movgen = "none",
					typical_state_time = 30,
					chance = 0,
					animation = "stand",
					graphics = {
						sprite_scale={x=4,y=4},
						sprite_div = {x=6,y=2},
						visible_height = 2.2,
						visible_width = 1,
					},
					graphics_3d = {
						visual = "mesh",
						mesh = "animal_freddie_freddie.b3d",
						textures = {"animal_freddie_freddie_mesh.png"},
						collisionbox = selectionbox_freddie,
						visual_size= {x=1,y=1,z=1},
						},
				},
				{
					name = "walking",
					movgen = "probab_mov_gen",
					typical_state_time = 120,
					chance = 0.5,
					animation = "walk",
				},
				{
					name = "combat",
					typical_state_time = 9999,
					chance = 0.0,
					animation = "attack",
					movgen="mgen_path",
				},
			}
		}


--compatibility code
minetest.register_entity("animal_freddie:freddie_spawner",
 {
	physical        = false,
	collisionbox    = { 0.0,0.0,0.0,0.0,0.0,0.0},
	visual          = "sprite",
	textures        = { "invisible.png^[makealpha:128,0,0^[makealpha:128,128,0" },
	on_activate = function(self,staticdata)

		local pos = self.object:getpos();
		minetest.add_entity(pos,"mobf:compat_spawner")
		self.object:remove()
	end,
})

minetest.register_entity("animal_freddie:freddie_spawner_at_night",
 {
	physical        = false,
	collisionbox    = { 0.0,0.0,0.0,0.0,0.0,0.0},
	visual          = "sprite",
	textures        = { "invisible.png^[makealpha:128,0,0^[makealpha:128,128,0" },
	on_activate = function(self,staticdata)

		local pos = self.object:getpos();
		minetest.add_entity(pos,"mobf:compat_spawner")
		self.object:remove()
	end,
})

minetest.register_entity("animal_freddie:freddie_spawner_shadows",
 {
	physical        = false,
	collisionbox    = { 0.0,0.0,0.0,0.0,0.0,0.0},
	visual          = "sprite",
	textures        = { "invisible.png^[makealpha:128,0,0^[makealpha:128,128,0" },
	on_activate = function(self,staticdata)

		local pos = self.object:getpos();
		minetest.add_entity(pos,"mobf:compat_spawner")
		self.object:remove()
	end,
})

--spawning code
local freddie_name   = freddie_prototype.modname .. ":"  .. freddie_prototype.name
local freddie_env = mobf_environment_by_name(freddie_prototype.generic.envid)

mobf_spawner_register("freddie_spawner_1",freddie_name,
	{
	spawnee = freddie_name,
	spawn_interval = 10,
	spawn_inside = freddie_env.media,
	entities_around =
		{
			{ type="MAX",distance=1,threshold=0 },
			{ type="MAX",entityname=freddie_name,
				distance=freddie_prototype.generic.population_density,threshold=2 },
		},

	absolute_height =
	{
		min = -10,
	},

	light_around =
	{
		{ type="TIMED_MIN", distance = 0, threshold=LIGHT_MAX +1,time=0.5 },
		{ type="TIMED_MAX", distance = 0, threshold=6,time=0.0 },
		{ type="CURRENT_MAX", distance = 0, threshold=5 }
	},

	daytimes =
	{
		{ begin = 0.75, stop=0.99 },
		{ begin = 0.0,  stop=0.25 },
	},

	surfaces = { "default:dirt_with_grass", "default:sand", "default:desert_sand"},
	collisionbox = selectionbox_freddie
	})

mobf_spawner_register("freddie_spawner_2",freddie_name,
	{
	spawnee = freddie_name,
	spawn_interval = 60,
	spawn_inside = freddie_env.media,
	entities_around =
		{
			{ type="MAX",distance=1,threshold=0 },
			{ type="MAX",entityname=freddie_name,
				distance=100,threshold=2 },
		},

	light_around =
	{
		{ type="OVERALL_MAX", distance = 2, threshold=6 }
	},

	absolute_height = {
		max = 100,
	},

	mapgen =
	{
		enabled = true,
		retries = 10,
		spawntotal = 3,
	},

	collisionbox = selectionbox_freddie
	})


--register with animals mod
minetest.log("action","\tadding mob "..freddie_prototype.name)
mobf_add_mob(freddie_prototype)
minetest.log("action","MOD: animal_freddie mod          version " .. version .. " loaded")